This archive contains datasets for the paper "Protein flexibility and intrinsic disorder" by Radivojac et al., Protein Science.

The files are in Matlab format and should be self explanatory (also see Materials and Methods from the paper).

Use load "dataset". Each dataset is stored as an array of structures. Each structure contains fields "sequence", "file name". Disorder dataset contains field "disorder" where 1 indicates a missing residue.

For any questions please contact Predrag Radivojac at predrag@ist.temple.edu